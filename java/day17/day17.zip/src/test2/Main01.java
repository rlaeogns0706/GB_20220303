package test2;

public class Main01 {

	public static void main(String[] args) {
		Student st = new Student("kjh", 2, 12, 95, 85, 30);
		
		System.out.println(st.info());
	
	}

}
