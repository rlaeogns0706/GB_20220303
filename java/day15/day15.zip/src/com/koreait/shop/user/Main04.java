package com.koreait.shop.user;

public class Main04 {

	public static void main(String[] args) {
		System.out.println("test");
	}

}
