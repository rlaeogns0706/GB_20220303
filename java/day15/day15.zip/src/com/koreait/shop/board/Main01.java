package com.koreait.shop.board;

public class Main01 {

	public static void main(String[] args) {
		Article.setCategory("자유게시판");
		
		
		
	}

}
